package _000.dao._000._alpha.a;
// gen getter & setter
import _000.dao._000._alpha.b.B_boolean_D_en;

public class Able_D_en 
extends B_boolean_D_en
{
boolean able;

public boolean isAble() {
	return able;
}

public _000.interf._000.a.Alpha_enI setAble(boolean able) {
	this.able = able;
	return getAlpha();
}
}
