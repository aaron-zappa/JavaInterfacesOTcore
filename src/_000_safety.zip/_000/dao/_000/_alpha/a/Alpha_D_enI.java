package _000.dao._000._alpha.a;

public interface Alpha_D_enI 
extends 	
Alpha_GD_enI
,Alpha_SD_enI

{
}
