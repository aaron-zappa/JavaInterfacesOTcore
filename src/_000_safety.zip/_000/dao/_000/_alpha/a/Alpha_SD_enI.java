package _000.dao._000._alpha.a;

public interface Alpha_SD_enI {
	public _000.interf._000.a.Alpha_enI setAlpha(_000.interf._000.a.Alpha_enI alpha);
}
