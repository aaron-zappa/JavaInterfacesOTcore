package _000.dao._000._alpha.b;

public interface B_boolean_D_enI {
	 boolean isBoolean_();
	 _000.interf._000.a.Alpha_enI setBoolean_(boolean boolean_);
	 Boolean newBoolean(boolean boolean_);
}
