package _000.dao._000._alpha.d.datatype;

public class S_D_en 
extends
_000.dao._000._alpha.a.Alpha_D_en
{
String s;

public String getS() {
	return s;
}

public _000.interf._000.a.Alpha_enI setS(String s) {
	this.s = s;
	return getAlpha();
}

}
