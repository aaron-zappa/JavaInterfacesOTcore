package _000.dao._000._alpha.d.datatype;

public class StringArr_D_en 
extends _000.imple._000._alpha.a.Alpha_H_en

implements StringArr_D_enI
{
String [] stringArr;

public String[] getStringArr() {
	return stringArr;
}

public  _000.interf._000.a.Alpha_enI setStringArr(String[] stringArr) {
	this.stringArr = stringArr;
	return getAlpha();
}

}
