package _000.dao._000._alpha.d.datatype;

public interface StringArr_D_enI 

{
	public String[] getStringArr();
	public  _000.interf._000.a.Alpha_enI setStringArr(String[] stringArr);
}
