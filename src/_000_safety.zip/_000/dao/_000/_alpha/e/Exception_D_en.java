package _000.dao._000._alpha.e;
//import java.io.*;

public class Exception_D_en
extends _000.dao._000._alpha.a.Alpha_D_en

{
Exception exception=null;

public Exception getException() {
	return exception;
}

public _000.interf._000.a.Alpha_enI setException(Exception exception) {
	this.exception = exception;
	return getAlpha();
}
}
