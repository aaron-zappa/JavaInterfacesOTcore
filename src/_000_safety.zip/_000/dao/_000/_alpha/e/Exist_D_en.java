package _000.dao._000._alpha.e;

public class Exist_D_en
extends _000.dao._000._alpha.b.B_boolean_D_en

implements Exist_D_enI
{
boolean exist;

public boolean isExist() {
	return exist;
}

public _000.interf._000.a.Alpha_enI setExist(boolean exist) {
	this.exist = exist;
	return getAlpha();
}



}
