package _000.dao._000._alpha.e;

public interface Exist_D_enI 
extends _000.dao._000._alpha.b.B_boolean_D_enI
{
	public _000.interf._000.a.Alpha_enI setExist(boolean exist);
	public boolean isExist();
	
}
