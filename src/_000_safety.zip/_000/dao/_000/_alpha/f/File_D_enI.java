package _000.dao._000._alpha.f;

import java.io.File;

public interface File_D_enI {
	public File getFile();
	public _000.interf._000.a.Alpha_enI setFile(File file);
	public _000.interf._000.a.Alpha_enI newFile(String fileName);
}
