package _000.dao._000._alpha.h;

import _000.dao._000._alpha.o.O_D_en;

public class Handler_D_en 
extends 
O_D_en
//_.dao._000._alpha.a.Alpha_D_en
{
	_000.interf._000.h.Handler_enI handler=null;

	public _000.interf._000.h.Handler_enI getHandler() {
		return handler;
	}

	public void setHandler(_000.interf._000.h.Handler_enI handler) {
		this.handler = handler;
	}
}
