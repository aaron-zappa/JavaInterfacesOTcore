package _000.dao._000._alpha.h;

public class Hidden_DA_en {
boolean hidden;
}
