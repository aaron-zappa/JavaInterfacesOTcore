package _000.dao._000._alpha.i;

import _000.dao._000._alpha.a.Alpha_D_en;

public class I_integer_D_en 
extends Alpha_D_en
implements I_integer_D_enI
{

int i=0;

public int getI() {
	return i;
}

public _000.interf._000.a.Alpha_enI setI(int i) {
	this.i = i;
	return getAlpha();
}


}
