package _000.dao._000._alpha.i;

public interface I_integer_D_enI
extends I_integer_GD_enI
{
	public _000.interf._000.a.Alpha_enI setI(int i);
}
