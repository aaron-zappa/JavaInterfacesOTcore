package _000.dao._000._alpha.i;

public interface I_integer_GD_enI {
	public int getI();
}
