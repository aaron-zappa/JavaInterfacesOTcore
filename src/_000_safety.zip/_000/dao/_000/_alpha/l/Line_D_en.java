package _000.dao._000._alpha.l;

public class Line_D_en 
extends _000.dao._000._alpha.d.datatype.S_D_en
{
String line;

public String getLine() {
	return line;
}

public _000.interf._000.a.Alpha_enI  setLine(String line) {
	this.line = line;
	return getAlpha();
}
}
