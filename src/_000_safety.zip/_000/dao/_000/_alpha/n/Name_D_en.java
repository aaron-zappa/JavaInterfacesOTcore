package _000.dao._000._alpha.n;

import java.io.File;

import _000.dao._000._alpha.n.Name_D_enI;

public class Name_D_en 
extends _000.dao._000._alpha.e.Exist_D_en

implements Name_D_enI
{
public String getName() {
		return name;
	}

	public _000.interf._000.a.Alpha_enI setName(String name) {
		this.name = name;
		return getAlpha();
	}

String name=null;
}
