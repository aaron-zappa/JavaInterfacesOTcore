package _000.dao._000._alpha.n;

public interface Name_D_enI {
	public String getName();
	public _000.interf._000.a.Alpha_enI setName(String name);
}
