package _000.dao._000._alpha.o;
//JI_DAO - Data Access Object

public class O_D_en 
extends _000.dao._000._alpha.a.Alpha_D_en
{
Object o=null;

public Object getO() {
	return o;
}

public _000.interf._000.a.Alpha_enI setO(Object o) {
	this.o = o;
	return getAlpha();
}
}
