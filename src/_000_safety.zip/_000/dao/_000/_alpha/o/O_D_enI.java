package _000.dao._000._alpha.o;

public interface O_D_enI {
	public Object getO();
	public _000.interf._000.a.Alpha_enI setO(Object o);
}
