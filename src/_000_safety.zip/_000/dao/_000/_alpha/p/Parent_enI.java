package _000.dao._000._alpha.p;

public interface Parent_enI {
	public Object getParent();
	public _000.interf._000.a.Alpha_enI setParent(Object parent);
}
