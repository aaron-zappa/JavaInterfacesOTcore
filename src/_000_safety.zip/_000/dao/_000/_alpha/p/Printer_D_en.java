package _000.dao._000._alpha.p;

import _000.interf._000.p.Printer_enI;


public class Printer_D_en {
Printer_enI printer=null; 
}
