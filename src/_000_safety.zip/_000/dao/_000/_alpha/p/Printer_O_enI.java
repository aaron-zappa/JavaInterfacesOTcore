package _000.dao._000._alpha.p;

public interface Printer_O_enI {
	public _000.interf._000.a.Alpha_enI print(Object o);
	public _000.interf._000.a.Alpha_enI println(Object o);
}
