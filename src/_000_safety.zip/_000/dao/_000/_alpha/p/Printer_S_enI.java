package _000.dao._000._alpha.p;

public interface Printer_S_enI {
	public _000.interf._000.a.Alpha_enI print(String s);
	public _000.interf._000.a.Alpha_enI println(String s);
}
