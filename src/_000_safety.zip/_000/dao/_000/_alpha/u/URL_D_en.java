package _000.dao._000._alpha.u;

public class URL_D_en 
extends _000.dao._000._alpha.a.Alpha_D_en
{
String URL;

public String getURL() {
	return URL;
}

public _000.interf._000.a.Alpha_enI setURL(String uRL) {
	URL = uRL;
	return getAlpha();
}

}
