package _000.dao._000._alpha.v;

public class Value_D_en 
extends _000.dao._000._alpha.a.Alpha_D_en
{
Object value;

public Object getValue() {
	return value;
}

public _000.interf._000.a.Alpha_D_enI setValue(Object value) {
	this.value = value;
	return getAlpha();
}
}
