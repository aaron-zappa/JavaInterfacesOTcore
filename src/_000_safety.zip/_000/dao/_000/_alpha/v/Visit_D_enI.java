package _000.dao._000._alpha.v;

import _000.interf._000.v.Visit_enI;

public interface Visit_D_enI {
	public Visit_enI getVisit();
	public _000.interf._000.a.Alpha_enI setVisit(Visit_enI visit) ;
}
