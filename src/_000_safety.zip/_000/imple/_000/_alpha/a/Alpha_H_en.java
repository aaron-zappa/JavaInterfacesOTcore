package _000.imple._000._alpha.a;

import _000.interf._000.a.Alpha_enI;

public class Alpha_H_en 
extends _000.dao._000._alpha.a.Alpha_D_en

implements 
_000.interf._000.a.Alpha_enI
{
	_000.interf._000.a.Alpha_enI alpha;
	
	public Alpha_enI init() {
		// TODO Auto-generated method stub
		return null;
	}

	public Alpha_enI test() {
		// TODO Auto-generated method stub
		return null;
	}

	public Alpha_enI n(Object o) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Alpha_enI setExist(boolean exist) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean isExist() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isBoolean_() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Alpha_enI setBoolean_(boolean boolean_) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Boolean newBoolean(boolean boolean_) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getName() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Alpha_enI setName(String name) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Alpha_enI print(Object o) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Alpha_enI println(Object o) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Alpha_enI print(String s) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Alpha_enI println(String s) {
		// TODO Auto-generated method stub
		return null;
	}

}
