package _000.imple._000._alpha.a;

import _000.interf._000.a.Actual_enI;
import _000.interf._000.a.Alpha_enI;
import _000.interf._000.e.Expected_enI;

public class Assert_H_en 
implements
Expected_enI
,Actual_enI
{

	@Override
	public Alpha_enI actual(Object actualObject) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Alpha_enI expected(Object expectedObject) {
		// TODO Auto-generated method stub
		return null;
	}

}
