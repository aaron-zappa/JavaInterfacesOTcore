package _000.imple._000._alpha.g;

import _000.dao._000._alpha.n.Name_D_en;
import _000.interf._000.a.Activate_enI;
import _000.interf._000.a.Alpha_enI;
import _000.interf._000.b.BeforeInit_enI;
import _000.interf._000.e.Execute_enI;
import _000.interf._000.i.Init_enI;
import _000.interf._000.t.Test_enI;
import _000.java.keyword._alpha.p.ClassC_enI;
import _000.java.keyword._alpha.p.Public_enI;
import _000.sym._alpha.b.BracketCloseCurlySym_enI;
import _000.sym._alpha.b.BracketOpenCurlySym_enI;

public class GenerateJavaClass_H_en 
extends GenerateSetter_enI
implements Init_enI,Test_enI,Execute_enI,Activate_enI,BeforeInit_enI
//Constants
,ClassC_enI
,BracketOpenCurlySym_enI
,BracketCloseCurlySym_enI
{
	protected Name_D_en name_D_en = new Name_D_en();

	public static void main(String[] args) { new GenerateJavaClass_H_en().activate(); }	
	
	@Override
	public Alpha_enI test() {
		execute();
		return getAlpha();
	}

	@Override
	public Alpha_enI init() {
		name_D_en.setName("Name");
		return getAlpha();
	}

	@Override
	public Alpha_enI execute() {
		println(Public_enI.visibility+blank+class_+blank+name_D_en.getName()+blank 
				+openCurly+BracketCloseCurlySym_enI.closeCurly
				);
		return getAlpha();
	}

	@Override
	public Alpha_enI activate() {
		beforeInit();
		return null;
	}

	@Override
	public Alpha_enI beforeInit() {
		// TODO Auto-generated method stub
		return null;
	}
	
	
}
