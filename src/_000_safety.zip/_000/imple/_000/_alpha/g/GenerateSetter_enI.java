package _000.imple._000._alpha.g;

import _000.interf._000.a.Alpha_enI;
import _000.interf._000.e.Execute_enI;
import _000.java.other.AlphaInterfaceConstant_enI;
import _000.java.other.GetTag_enI;
import _000.java.other.SetTag_enI;

public class GenerateSetter_enI 
extends GenerateGetter_H
implements Execute_enI
,AlphaInterfaceConstant_enI
{

	@Override
	public Alpha_enI execute() {
		s_D_en.setS(visibility+blank
				+alphaInterface
				+blank+SetTag_enI.tag
				+s_D_en.getS()
				//+DAO_Postfix_enI.dAO_Postfix+
		+bracketOpenSym
		+typ_D_en.getS()
		+blank
		+generateGetJavaNameOfTypeLower(s_D_en.getS())
		+bracketCloseSym);
		
		println(s_D_en.getS());
		return getAlpha();
	}

}
