package _000.imple._000._alpha.m;

//later junit Adapter
//import org.junit.Test;
//import static org.junit.Assert.*;

import _000.imple._000._alpha.e.Exist_H_en;
import _000.interf._000.a.Alpha_enI;


public class Assert_H_en
extends Exist_H_en

//_.dao._000._alpha.a.Alpha_D_en
//_.imple._000._alpha.a.Alpha_H_en

implements 
_000.interf._000.m.Main_enI
,_000.interf._000.t.Test_enI
,_000.interf._000.i.Init_enI
,_000.interf._000.a.Activate_enI
,_000.interf._000.a.Assert_P2_enI
,_000.interf._000.j.JuTest_enI
{
	
	public static void main(String[] args) { new Main_H_en().activate(); }

	@Override
	public Alpha_enI activate() {
		init().test();
		return getAlpha();
	}

//	@Override
//	public Alpha_enI init() {		return getAlpha(); }

	@Override
	public Alpha_enI test() {
		juTest();
		return getAlpha();
	}

//later junit Adapter
//@Test
	@Override
	public Alpha_enI assert_(Object expected, Object actual) {
		assertEquals(expected,actual);
		return getAlpha();
	}
	@Override

	public Alpha_enI juTest() {
		assert_(exist_D_en.newBoolean(exist_D_en.isExist()),exist_D_en.newBoolean(true));
		return getAlpha();
	}


}
