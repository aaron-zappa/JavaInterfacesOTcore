package _000.imple._000._alpha.t;

import java.io.BufferedReader;
import java.io.IOException;

import _000.imple._000._alpha.a.Alpha_H_en;
import _000.imple._000._alpha.s.SystemPrint_H_en;
import _000.interf._000.a.Alpha_enI;
import _000.interf._000.r.ReadLine_enI;
import _000.interf._000.t.Try1_enI;
import _000.interf._000.t.Try_enI;

public class ReadNormal_H_en 
extends 	SystemPrint_H_en
implements 	ReadLine_enI
{

	@Override
	public String readLine(BufferedReader bufferedReader) {
		String s=null;
		try {
			s = bufferedReader.readLine();
		} catch (IOException e) {
			e.printStackTrace();
			exit();
		}
		return s;
	}

	private void exit() {
		System.exit(0);		
	}


	
}
