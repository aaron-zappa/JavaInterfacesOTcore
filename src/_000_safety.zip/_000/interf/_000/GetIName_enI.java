package _000.interf._000;

public interface GetIName_enI {
	String getIName();
}
