package _000.interf._000.a;

public interface Activate_enI {
	public _000.interf._000.a.Alpha_enI activate();
}
