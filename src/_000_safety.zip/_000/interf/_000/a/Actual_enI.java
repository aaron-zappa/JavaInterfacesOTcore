package _000.interf._000.a;

public interface Actual_enI {
	public _000.interf._000.a.Alpha_enI actual(Object actualObject);
}
