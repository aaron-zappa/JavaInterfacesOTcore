package _000.interf._000.a;
import _000.dao._000._alpha.e.Exist_D_enI;
import _000.dao._000._alpha.n.Name_D_enI;

public interface Alpha_D_enI 
extends
//e
Exist_D_enI
//n
,Name_D_enI
{	
}
