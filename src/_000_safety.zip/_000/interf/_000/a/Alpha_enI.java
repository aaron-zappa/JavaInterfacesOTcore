package _000.interf._000.a;

public interface Alpha_enI 
extends 
_000.interf._000.a.Alpha_D_enI
,_000.interf._000.h.Handler_enI
,_000.interf._000.n.Null_O1_enI
,_000.interf._000.i.Init_enI
// t
,_000.interf._000.t.Test_enI
//p
,_000.interf._000.p.Printer_enI

{

}
