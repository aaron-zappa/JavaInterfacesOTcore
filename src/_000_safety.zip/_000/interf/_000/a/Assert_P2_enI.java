package _000.interf._000.a;

public interface Assert_P2_enI {
	public _000.interf._000.a.Alpha_enI assert_(Object expected,Object actual);
}
