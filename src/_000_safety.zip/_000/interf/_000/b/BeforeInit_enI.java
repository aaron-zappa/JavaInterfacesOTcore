package _000.interf._000.b;

import _000.interf._000.a.Alpha_enI;

// this init works for Handlers who need all three init,exec,finish
public interface BeforeInit_enI {
	public Alpha_enI beforeInit();
}
