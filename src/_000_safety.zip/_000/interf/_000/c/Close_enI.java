package _000.interf._000.c;

public interface Close_enI {

}
