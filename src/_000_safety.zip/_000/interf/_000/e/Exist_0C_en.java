package _000.interf._000.e;

import _000.interf._000.a.Alpha_enI;

public class Exist_0C_en implements Exist_enI {

	@Override
	public Alpha_enI exist() {
		// TODO Auto-generated method stub
		return null;
	}

}
