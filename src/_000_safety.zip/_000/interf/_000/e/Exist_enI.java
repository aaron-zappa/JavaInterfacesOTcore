package _000.interf._000.e;

public interface Exist_enI 
{
	public _000.interf._000.a.Alpha_enI exist();
}
