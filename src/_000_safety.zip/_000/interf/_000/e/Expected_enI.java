package _000.interf._000.e;

public interface Expected_enI {
	public _000.interf._000.a.Alpha_enI expected(Object expectedObject);
}
