package _000.interf._000.f;

public interface File_enI {
	public _000.interf._000.a.Alpha_enI file();
}
