package _000.interf._000.f;

public interface First_enI {

}
