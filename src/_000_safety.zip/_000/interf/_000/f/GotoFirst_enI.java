package _000.interf._000.f;

import _000.interf._000.g.Goto_enI;

public interface GotoFirst_enI 
extends Goto_enI
{

}
