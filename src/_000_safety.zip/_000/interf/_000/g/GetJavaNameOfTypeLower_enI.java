package _000.interf._000.g;

public interface GetJavaNameOfTypeLower_enI {
	public String generateGetJavaNameOfTypeLower(String s);
}