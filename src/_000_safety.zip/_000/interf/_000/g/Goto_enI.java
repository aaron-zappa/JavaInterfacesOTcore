package _000.interf._000.g;

import _000.interf._000.h.HasUnderscoreI;

public interface Goto_enI 
extends HasUnderscoreI
{
	public _000.interf._000.a.Alpha_enI goto_();
}
