package _000.interf._000.h;

public interface Handler_enI {

}
