package _000.interf._000.i;

public interface Init_enI {
	public _000.interf._000.a.Alpha_enI init();
}
