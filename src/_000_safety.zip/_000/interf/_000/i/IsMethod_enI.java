package _000.interf._000.i;

public interface IsMethod_enI {

}
