package _000.interf._000.i.is;

public interface IsFirst_enI 
extends Is_enI
{

}
