package _000.interf._000.i.is;

public interface Is_enI {

}
