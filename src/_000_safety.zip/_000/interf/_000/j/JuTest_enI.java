package _000.interf._000.j;

public interface JuTest_enI {
	public _000.interf._000.a.Alpha_enI juTest();
}
