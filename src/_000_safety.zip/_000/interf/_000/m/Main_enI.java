package _000.interf._000.m;

public interface Main_enI {
	String iName="Main_enI";
	//this interface can be used for all Classes who have a main method
	//	public static void main(String[] args) {}
}
