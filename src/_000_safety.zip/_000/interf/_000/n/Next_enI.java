package _000.interf._000.n;

public interface Next_enI {
	public _000.interf._000.a.Alpha_enI next();
}
