package _000.interf._000.o;

import _000.interf._000.a.Alpha_enI;

public interface ObjectAssert_enI {
	public Alpha_enI assert_(Object expected, Object actual);
}
