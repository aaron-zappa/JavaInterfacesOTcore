package _000.interf._000.o;

public interface Open_enI {

}
