package _000.interf._000.p;

import _000.dao._000._alpha.p.Printer_O_enI;
import _000.dao._000._alpha.p.Printer_S_enI;

public interface Printer_enI 
extends Printer_O_enI,Printer_S_enI
{

}
