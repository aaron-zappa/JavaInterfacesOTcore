package _000.interf._000.r;

import java.io.BufferedReader;

public interface ReadLine_enI {
	public String readLine(BufferedReader bufferedReader);
}
