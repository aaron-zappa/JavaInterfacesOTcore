package _000.interf._000.s;

public interface Size_enI {

}
