package _000.interf._000.t;
public interface Test_enI {
	public _000.interf._000.a.Alpha_enI test();
}
