package _000.interf._000.t;

public interface Try1_enI {
	public _000.interf._000.a.Alpha_enI try1(_000.interf._000.a.Alpha_enI x) throws Exception;
}
