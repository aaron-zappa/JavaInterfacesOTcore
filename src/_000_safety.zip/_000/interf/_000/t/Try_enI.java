package _000.interf._000.t;

public interface Try_enI {
	public _000.interf._000.a.Alpha_enI try_(_000.interf._000.a.Alpha_enI x) ;
}
