package _000.interf._000.v;

public interface Visit_enI {
	public _000.interf._000.a.Alpha_enI visit();
}
