package _000.java.keyword._alpha.p;

public interface ClassC_enI {
String class_ ="class";
}
