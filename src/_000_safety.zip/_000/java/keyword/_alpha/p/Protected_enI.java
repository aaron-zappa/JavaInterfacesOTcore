package _000.java.keyword._alpha.p;

import _000.interf._000.h.HasUnderscoreI;

public interface Protected_enI extends 
HasUnderscoreI
{
	String visibility ="protected";
//	public _.interf._000.a.Alpha_enI protected_();
}
