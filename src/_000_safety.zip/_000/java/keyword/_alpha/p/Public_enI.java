package _000.java.keyword._alpha.p;

public interface Public_enI {
	String visibility ="public";

//	public _.interf._000.a.Alpha_enI public_();
}
