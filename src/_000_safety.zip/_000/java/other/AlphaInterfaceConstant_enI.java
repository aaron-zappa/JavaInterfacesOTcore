package _000.java.other;

public interface AlphaInterfaceConstant_enI {
String iname = "AlphaInterfaceConstant_enI";
String alphaInterface = "_.interf._000.a.Alpha_enI";
}
