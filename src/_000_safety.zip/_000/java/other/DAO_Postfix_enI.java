package _000.java.other;

public interface DAO_Postfix_enI 
extends _2LetterLanguageEnglish_enI,InterfacePostfix_enI
{
String dAO_Postfix = "_D_"+_2LetterLanguageEnglish_enI._2letterLang+InterfacePostfix_enI.postfix;
}
