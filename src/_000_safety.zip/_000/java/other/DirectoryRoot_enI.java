package _000.java.other;

public interface DirectoryRoot_enI {
String root = "C:/raoul/tmp";
}
