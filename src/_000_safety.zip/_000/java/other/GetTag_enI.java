package _000.java.other;

public interface GetTag_enI {
	String tag="get";
}
