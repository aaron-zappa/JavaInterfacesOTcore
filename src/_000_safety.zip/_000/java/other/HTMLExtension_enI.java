package _000.java.other;

public interface HTMLExtension_enI {

}
