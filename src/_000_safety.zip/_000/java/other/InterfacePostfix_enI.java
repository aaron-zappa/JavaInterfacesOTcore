package _000.java.other;

public interface InterfacePostfix_enI {
String postfix="I";
}
