package _000.java.other;

public interface JavaExtension_enI {
String extension = ".java";
}
