package _000.java.other;

public interface SetTag_enI {
String tag="set";
}
