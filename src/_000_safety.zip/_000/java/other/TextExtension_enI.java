package _000.java.other;

public interface TextExtension_enI {

}
