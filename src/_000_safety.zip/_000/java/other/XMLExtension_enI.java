package _000.java.other;

public interface XMLExtension_enI {

}
