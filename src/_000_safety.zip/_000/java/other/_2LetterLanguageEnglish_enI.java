package _000.java.other;

public interface _2LetterLanguageEnglish_enI {
String _2letterLang ="en";
}
