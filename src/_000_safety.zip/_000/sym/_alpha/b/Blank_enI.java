package _000.sym._alpha.b;

public interface Blank_enI {
String blank=" ";
}
