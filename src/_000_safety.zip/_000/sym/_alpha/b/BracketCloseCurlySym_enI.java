package _000.sym._alpha.b;

public interface BracketCloseCurlySym_enI {
	String closeCurly = "}";
}
