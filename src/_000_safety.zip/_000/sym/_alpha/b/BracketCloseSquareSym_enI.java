package _000.sym._alpha.b;

import _000.interf._000.c.Close_enI;

public interface BracketCloseSquareSym_enI
extends Close_enI
,BracketSym_enI

{
	String symbol="]";
}
