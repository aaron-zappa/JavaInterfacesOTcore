package _000.sym._alpha.b;


public interface BracketCloseSym_enI 
extends
BracketSym_enI
{
	String bracketCloseSym=")";

}
