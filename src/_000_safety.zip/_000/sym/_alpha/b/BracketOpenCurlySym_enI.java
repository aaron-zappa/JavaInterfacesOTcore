package _000.sym._alpha.b;

public interface BracketOpenCurlySym_enI {
	String openCurly = "{";
}
