package _000.sym._alpha.b;

public interface BracketOpenSquareSym_enI 
extends BracketSym_enI
{
	String symbol="[";

}
