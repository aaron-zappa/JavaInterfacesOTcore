package _000.sym._alpha.b;

import _000.interf._000.o.Open_enI;

public interface BracketOpenSym_enI 
extends Open_enI
,BracketSym_enI
{
	String bracketOpenSym="(";
}
