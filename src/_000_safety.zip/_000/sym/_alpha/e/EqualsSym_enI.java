package _000.sym._alpha.e;

import _000.sym._alpha.s.Symbol_enI;

public interface EqualsSym_enI 
extends Symbol_enI
{

}
