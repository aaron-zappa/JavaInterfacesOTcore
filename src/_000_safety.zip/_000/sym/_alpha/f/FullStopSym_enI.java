package _000.sym._alpha.f;

import _000.sym._alpha.s.Symbol_enI;

public interface FullStopSym_enI 
extends Symbol_enI

{

}
