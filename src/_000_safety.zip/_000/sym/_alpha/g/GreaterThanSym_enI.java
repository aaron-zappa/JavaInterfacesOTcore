package _000.sym._alpha.g;

import _000.sym._alpha.s.Symbol_enI;

public interface GreaterThanSym_enI 
extends Symbol_enI

{
	String symbol=">";
}
