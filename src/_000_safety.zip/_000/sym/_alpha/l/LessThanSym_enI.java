package _000.sym._alpha.l;

import _000.sym._alpha.s.Symbol_enI;

public interface LessThanSym_enI 
extends Symbol_enI

{
	String symbol="<";
}
