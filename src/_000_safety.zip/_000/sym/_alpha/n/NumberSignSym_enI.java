package _000.sym._alpha.n;

import _000.sym._alpha.s.Symbol_enI;

public interface NumberSignSym_enI 
extends Symbol_enI

{
	String symbol="#";
}
