package _000.sym._alpha.s;

public interface SlashSym_enI 
extends Symbol_enI

{
	String symbol="/";

}
