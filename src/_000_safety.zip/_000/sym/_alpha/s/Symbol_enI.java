package _000.sym._alpha.s;

public interface Symbol_enI {
//String symbol="";
}
